var global_navtree = WpNavBar.readTree({
"childArray" : [
{   'sDescription':'Joblings Garage is a small and friendly family run business trading in Cullercoats, Whitley Bay established in 2002.  We became a Bosch Car service Centre in 2008.\r\nWe aim to be your first choice for motor repair and servicing needs. Providing you with affordable and the very best customer service possible',
'sTitle':'Home',
'bIsWebPath':true,
'sUrl':'index.html',
'sTarget':'_self'
},
{   'sDescription':'Joblings Garage is a small and friendly family run business trading in Cullercoats, Whitley Bay established in 2002.  We became a Bosch Car service Centre in 2008.\r\nWe aim to be your first choice for motor repair and servicing needs. Providing you with affordable and the very best customer service possible',
'sTitle':'About Us',
'bIsWebPath':true,
'sUrl':'about.html',
'sTarget':'_self'
},
{   'sDescription':'Joblings Garage is a small and friendly family run business trading in Cullercoats, Whitley Bay established in 2002.  We became a Bosch Car service Centre in 2008.\r\nWe aim to be your first choice for motor repair and servicing needs. Providing you with affordable and the very best customer service possible',
'sTitle':'Service',
'bIsWebPath':true,
'sUrl':'service.html',
'sTarget':'_self'
},
{   'sDescription':'Joblings Garage is a small and friendly family run business trading in Cullercoats, Whitley Bay established in 2002.  We became a Bosch Car service Centre in 2008.\r\nWe aim to be your first choice for motor repair and servicing needs. Providing you with affordable and the very best customer service possible',
'sTitle':'Contact',
'bIsWebPath':true,
'sUrl':'contact.html',
'sTarget':'_self'
}]
});
